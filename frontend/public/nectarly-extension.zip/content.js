"use strict";
(() => {
  // src/detect.ts
  var TRIGGER_TEXT = /add to (cart|bag)|buy now|checkout|place order/i;
  var MAX_ANCESTOR_DEPTH = 3;
  var MAX_TRIGGER_TEXT_LENGTH = 60;
  function isCheckoutTrigger(target) {
    let el = target;
    for (let depth = 0; el && depth <= MAX_ANCESTOR_DEPTH; depth++, el = el.parentElement) {
      const text = el.textContent?.trim();
      if (text && text.length <= MAX_TRIGGER_TEXT_LENGTH && TRIGGER_TEXT.test(text)) {
        return true;
      }
    }
    return false;
  }
  function parsePrice(value) {
    const num = typeof value === "string" ? parseFloat(value) : typeof value === "number" ? value : NaN;
    return Number.isFinite(num) ? num : null;
  }
  function findProductNode(data) {
    const nodes = Array.isArray(data) ? data : [data];
    for (const node of nodes) {
      if (!node || typeof node !== "object") continue;
      const record = node;
      if (record["@type"] === "Product") return record;
      if (Array.isArray(record["@graph"])) {
        const found = record["@graph"].find(
          (n) => n && typeof n === "object" && n["@type"] === "Product"
        );
        if (found) return found;
      }
    }
    return null;
  }
  function fromJsonLd(doc) {
    const scripts = doc.querySelectorAll('script[type="application/ld+json"]');
    for (const script of scripts) {
      let data;
      try {
        data = JSON.parse(script.textContent || "");
      } catch {
        continue;
      }
      const product = findProductNode(data);
      if (!product) continue;
      const offers = Array.isArray(product.offers) ? product.offers[0] : product.offers;
      const image = Array.isArray(product.image) ? product.image[0] : product.image;
      return {
        title: String(product.name ?? ""),
        price: parsePrice(offers?.price),
        image: typeof image === "string" ? image : null
      };
    }
    return null;
  }
  function fromOpenGraph(doc) {
    const title = doc.querySelector('meta[property="og:title"]')?.getAttribute("content");
    if (!title) return null;
    const priceRaw = doc.querySelector('meta[property="product:price:amount"]')?.getAttribute("content");
    const image = doc.querySelector('meta[property="og:image"]')?.getAttribute("content") ?? null;
    return { title, price: parsePrice(priceRaw), image };
  }
  function extractProduct(doc) {
    return fromJsonLd(doc) ?? fromOpenGraph(doc) ?? { title: doc.title, price: null, image: null };
  }

  // src/popup.ts
  var STYLES = `
  :host { all: initial; }
  .panel {
    position: fixed; top: 16px; right: 16px; z-index: 2147483647;
    width: 320px; max-width: calc(100vw - 32px);
    font-family: system-ui, sans-serif; font-size: 13px; color: #2b2b28;
    background: #f7f5f1; border: 1px solid #ddd8cf; border-radius: 12px;
    box-shadow: 0 8px 24px rgba(0,0,0,0.18); padding: 16px;
  }
  .header { display: flex; align-items: center; gap: 8px; margin-bottom: 12px; }
  .brand { font-weight: 700; color: #a15c2f; margin-right: auto; }
  .close { border: none; background: transparent; cursor: pointer; font-size: 16px; line-height: 1; color: #6b6b63; }
  .savings { background: #eef3e6; border: 1px solid #cdddb8; border-radius: 8px; padding: 12px; margin-bottom: 12px; }
  .savings-label { text-transform: uppercase; font-size: 10px; letter-spacing: 0.08em; color: #4c6b2f; margin: 0 0 4px; }
  .savings-amount { font-size: 32px; font-weight: 700; color: #4c6b2f; margin: 0; line-height: 1; }
  .list-label { text-transform: uppercase; font-size: 10px; letter-spacing: 0.08em; color: #6b6b63; margin: 12px 0 8px; font-weight: 700; }
  .item { display: flex; align-items: center; gap: 10px; border: 1px solid #ddd8cf; border-radius: 8px; padding: 10px; margin-bottom: 8px; }
  .item img { width: 32px; height: 32px; object-fit: contain; border-radius: 4px; flex-shrink: 0; }
  .item-title { font-weight: 700; margin: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .item-meta { color: #6b6b63; font-size: 11px; margin: 2px 0 0; }
  .item-price { margin-left: auto; font-weight: 700; flex-shrink: 0; }
  .open-comparison { width: 100%; border: none; border-radius: 999px; background: #a15c2f; color: #fff; padding: 10px; font-weight: 700; cursor: pointer; margin-top: 8px; }
  .status { padding: 24px 4px; text-align: center; color: #6b6b63; }
`;
  var host = null;
  var shadow = null;
  function escapeHtml(text) {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  function ensureHost() {
    if (shadow) return shadow;
    host = document.createElement("div");
    document.body.appendChild(host);
    shadow = host.attachShadow({ mode: "closed" });
    return shadow;
  }
  function wireClose(root) {
    root.querySelector(".close")?.addEventListener("click", close);
  }
  function renderLoading() {
    const root = ensureHost();
    root.innerHTML = `
    <style>${STYLES}</style>
    <div class="panel">
      <div class="header"><span class="brand">nectarly</span><button class="close">&times;</button></div>
      <div class="status">Searching for equivalents\u2026</div>
    </div>
  `;
    wireClose(root);
  }
  function renderError(message) {
    const root = ensureHost();
    root.innerHTML = `
    <style>${STYLES}</style>
    <div class="panel">
      <div class="header"><span class="brand">nectarly</span><button class="close">&times;</button></div>
      <div class="status">${escapeHtml(message)}</div>
    </div>
  `;
    wireClose(root);
  }
  function renderResults(state, onOpenComparison) {
    const root = ensureHost();
    const best = state.products[0] ?? null;
    const savings = best && state.targetPrice != null ? state.targetPrice - best.price : null;
    const savingsBlock = best && savings != null && savings > 0 ? `<div class="savings">
           <p class="savings-label">You could keep</p>
           <p class="savings-amount">$${savings.toFixed(0)}</p>
         </div>` : "";
    const items = state.products.slice(0, 4).map(
      (p) => `
        <div class="item">
          ${p.image && /^https?:\/\//.test(p.image) ? `<img src="${escapeHtml(p.image)}" alt="">` : ""}
          <div>
            <p class="item-title">${escapeHtml(p.short)}</p>
            <p class="item-meta">${Math.round(p.matchScore)}% match \xB7 ${p.rating.toFixed(1)}\u2605</p>
          </div>
          <span class="item-price">$${p.price.toFixed(0)}</span>
        </div>`
    ).join("");
    root.innerHTML = `
    <style>${STYLES}</style>
    <div class="panel">
      <div class="header"><span class="brand">nectarly</span><button class="close">&times;</button></div>
      ${savingsBlock}
      <p class="list-label">Equivalents found</p>
      ${items || `<div class="status">No equivalents found.</div>`}
      <button class="open-comparison">Open full comparison</button>
    </div>
  `;
    wireClose(root);
    root.querySelector(".open-comparison")?.addEventListener("click", onOpenComparison);
  }
  function close() {
    host?.remove();
    host = null;
    shadow = null;
  }

  // src/content.ts
  function toPopupProduct(p) {
    return { short: p.short, price: p.price, matchScore: p.matchScore, rating: p.rating, image: p.image };
  }
  document.addEventListener(
    "click",
    (event) => {
      if (!isCheckoutTrigger(event.target)) return;
      const { title } = extractProduct(document);
      if (!title) return;
      renderLoading();
      chrome.runtime.sendMessage(
        { type: "search", title },
        (response) => {
          if (chrome.runtime.lastError || !response?.ok || !response.data) {
            renderError("Couldn't reach nectarly right now.");
            return;
          }
          const { targetProduct, groups } = response.data;
          const products = [...groups.same_spec, ...groups.same_job, ...groups.clears_floor].map(
            toPopupProduct
          );
          renderResults({ targetPrice: targetProduct?.price ?? null, products }, () => {
            window.open(`${"http://localhost:5173"}/?q=${encodeURIComponent(title)}`, "_blank");
          });
        }
      );
    },
    // Capture phase: a page's own handler calling stopPropagation on the button
    // must not hide the click from us.
    true
  );
})();
