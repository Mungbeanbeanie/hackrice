"use strict";
(() => {
  // src/background.ts
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const request = message;
    if (request?.type !== "search" || typeof request.title !== "string") {
      return false;
    }
    fetch(`${"http://localhost:8000"}/api/search`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: request.title })
    }).then(async (res) => {
      if (!res.ok) throw new Error(`API ${res.status}`);
      sendResponse({ ok: true, data: await res.json() });
    }).catch((err) => {
      sendResponse({ ok: false, error: String(err) });
    });
    return true;
  });
})();
